const restaurantsContainer = document.querySelector('.restaurants-container');
const vechileContainer = document.querySelector('.vichile-container');
const famousContainer = document.querySelector('.famous-container');
const restaurantsCard = document.getElementById('restaurants');
const vechileCard = document.getElementById('vechile');
const famousCard = document.getElementById('famous');
const seeRestaurantsButton = document.getElementById('see-restaurants');
const seeVechileButton = document.getElementById('see-vechile');
const seeFamousButton = document.getElementById('see-famous');
const closeButton = document.querySelector('#close-button');

var resp = fetch('../db/database.json')
.then(res => res.json())
.then((result) => {
  console.log(result.polygon2);
  const helpContainers = document.querySelector('.help-containers');

  
  seeRestaurantsButton.addEventListener('click', (e) => {
    result.polygon1.restaurants.forEach((item) => {
      cloneRestaurantCard(item);
    });
    openHelpContainer(e.target);
  });

  seeVechileButton.addEventListener('click', (e) => {
    result.polygon1.vechile.forEach((item) => {
      cloneVechileCard(item);
    });
    openHelpContainer(e.target);
  });

  seeFamousButton.addEventListener('click', (e) => {
    result.polygon1.famousPlace.forEach((item) => {
      cloneFamousCard(item);
    });
    openHelpContainer(e.target);
  });


  const cloneRestaurantCard = ((item) => {
    var clone = restaurantsCard.content.cloneNode(true);
    const cardImg = clone.querySelector('.card__img');
    const cardTtile = clone.querySelector('.card__title');
    const cardKitchen = clone.querySelector('.card__kitchen-type');
    const cardMidlePrice = clone.querySelector('.card__middle-price');
    cardImg.src = item.img;
    cardTtile.textContent = item.name;
    cardKitchen.textContent = item.kitchen;
    cardMidlePrice.textContent = item.middlePrice;
    
    restaurantsContainer.prepend(clone);
  });

  const cloneVechileCard = ((item) => {
    var clone = vechileCard.content.cloneNode(true);
    const cardImg = clone.querySelector('.card__img');
    const cardTtile = clone.querySelector('.card__title');
    cardImg.src = item.img;
    cardTtile.textContent = item.type;
    
    vechileContainer.prepend(clone);
  });

  const cloneFamousCard = ((item) => {
    var clone = famousCard.content.cloneNode(true);
    const cardImg = clone.querySelector('.card__img');
    const cardTtile = clone.querySelector('.card__title');
    const cardDescriprion = clone.querySelector('.card__description');
    cardImg.src = item.img;
    cardTtile.textContent = item.name;
    cardDescriprion.textContent = item.description;

    famousContainer.prepend(clone);
  });

  const openHelpContainer = ((traget) => {
    traget.classList.add('hidden');
    closeButton.classList.remove('hidden');
    helpContainers.style.rowGap = "10px";
    helpContainers.style.padding = "10px";
  });
    
  closeButton.addEventListener('click', () => {
    seeRestaurantsButton.classList.remove('hidden');
    seeVechileButton.classList.remove('hidden');
    seeFamousButton.classList.remove('hidden');
    closeButton.classList.add('hidden');
    helpContainers.style.removeProperty('row-gap');
    helpContainers.style.removeProperty('padding');
    const cardList = document.querySelectorAll('.card');
    cardList.forEach((item) => {
      item.remove();
    });
  });
});
