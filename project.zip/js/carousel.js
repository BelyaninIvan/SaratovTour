$(document).ready(function () {
    $("#carousel-header").owlCarousel({
        items: 1,
        nav: true,
        dots: false,
        navText: []
    });
});